LoopGrid Evidence Bundle v2

Verify integrity: python loopgrid_verify.py <bundle.zip>
Pin signer identity: python loopgrid_verify.py <bundle.zip> --expected-key-id <key-id>
or: python loopgrid_verify.py <bundle.zip> --trusted-public-key <public.pem>

No LoopGrid server connection is required. The embedded public key proves integrity under that key; signer authenticity should be pinned out-of-band for high-assurance use.
FULL mode raw payloads are encrypted outside the signed ledger; disclosures.jsonl is optional and commitment-checked.
chain-witness.jsonl contains proof-only bridge nodes and no unrelated decision payloads.
verification.json records export-time server verification; always run the offline verifier independently when relying on the evidence.
